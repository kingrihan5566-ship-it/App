package com.nakshinoor.payapp

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.Gravity
import android.widget.*
import org.json.JSONArray

/** One screen, built in code (no extra libraries). */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var url: EditText
    private lateinit var key: EditText
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 3000) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(24), dp(18), dp(24)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#fff7fa")); addView(root) }
        fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply { text = t; textSize = size; setTextColor(Color.parseColor("#2a1a22")); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, dp(10), 0, dp(4)) }
        root.addView(label("NakshiNoor Pay Listener", 22f, true))
        status = label("", 14f); root.addView(status)
        root.addView(label("Server address (from Admin → Own gateway → Phone app setup)", 12f))
        url = EditText(this).apply { setText(Forwarder.url(this@MainActivity)); hint = "https://nakshinoor.com/api/pay-app"; inputType = InputType.TYPE_TEXT_VARIATION_URI; setSingleLine() }
        root.addView(url)
        root.addView(label("Secret key", 12f))
        key = EditText(this).apply { setText(Forwarder.key(this@MainActivity)); hint = "paste the key"; setSingleLine() }
        root.addView(key)
        root.addView(btn("Save and test connection") {
            Forwarder.prefs(this).edit().putString("url", url.text.toString().trim()).putString("key", key.text.toString().trim()).apply()
            Toast.makeText(this, "Testing…", Toast.LENGTH_SHORT).show()
            Thread { val r = Forwarder.testConnection(this); h.post { Toast.makeText(this, r, Toast.LENGTH_LONG).show(); Thread { Forwarder.flush(this) }.start() } }.start()
        })
        root.addView(label("Permissions (needed so the app can read payment messages)", 12f))
        root.addView(btn("1. Allow notification access") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) })
        root.addView(btn("2. Allow SMS") { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS), 1) })
        root.addView(btn("3. Never sleep (battery)") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } })
        root.addView(btn("Send a test message") {
            Forwarder.handle(this, "bKash", "You have received Tk 1.00 from 01700000000. Fee Tk 0.00. Balance Tk 1.00. TrxID TEST" + (System.currentTimeMillis() % 100000) + " at 01/01/2026 10:00")
        })
        root.addView(label("Recent activity", 12f))
        logView = TextView(this).apply { textSize = 11f; setTextColor(Color.parseColor("#4a3a42")); typeface = android.graphics.Typeface.MONOSPACE }
        root.addView(logView)
        setContentView(sv)
    }

    private fun refresh() {
        val listener = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        val sms = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        val bat = Build.VERSION.SDK_INT < 23 || (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        fun m(b: Boolean) = if (b) "✓" else "✗"
        status.text = "${m(listener)} Notification access    ${m(sms)} SMS    ${m(bat)} Battery unrestricted\n${m(Forwarder.url(this).isNotEmpty() && Forwarder.key(this).isNotEmpty())} Server set up    Waiting to send: ${Forwarder.pending(this)}"
        val a = JSONArray(Forwarder.prefs(this).getString("log", "[]")); val sb = StringBuilder()
        for (i in 0 until a.length()) sb.append(a.getString(i)).append("\n")
        logView.text = if (sb.isEmpty()) "Nothing yet." else sb.toString()
        if (listener) try { NotificationListenerService.requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }
    override fun onResume() { super.onResume(); h.post(tick); Thread { Forwarder.flush(this) }.start() }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
