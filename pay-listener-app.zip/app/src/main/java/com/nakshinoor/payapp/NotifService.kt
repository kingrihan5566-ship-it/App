package com.nakshinoor.payapp

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads notifications (bKash, Nagad, Rocket and bank apps, and SMS apps). */
class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val e = sbn.notification.extras
            val title = e.getCharSequence("android.title")?.toString() ?: ""
            val big = e.getCharSequence("android.bigText")?.toString()
            val text = big ?: e.getCharSequence("android.text")?.toString() ?: ""
            if (text.isBlank()) return
            // For SMS apps the title is the sender; for MFS apps, use the app name from the package as a hint.
            val from = if (title.isNotBlank()) title + " " + sbn.packageName else sbn.packageName
            Forwarder.handle(applicationContext, from, text)
        } catch (_: Exception) {}
    }
    override fun onListenerConnected() { Forwarder.log(applicationContext, "Notification reader connected"); Thread { Forwarder.flush(applicationContext) }.start() }
}
