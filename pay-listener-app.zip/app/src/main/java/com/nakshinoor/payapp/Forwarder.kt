package com.nakshinoor.payapp

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Decides which messages look like "money received", stores them, and posts them to the server. */
object Forwarder {
    private const val PREFS = "pay"
    private val lock = Any()

    // Sender names / app names we care about.
    private val SENDERS = listOf("bkash", "nagad", "rocket", "16216", "dbbl", "islami", "ibbl", "prime", "pbl", "city", "citybank", "upay")
    // Notification package names (best known; text matching below also catches others).
    private val PACKAGES = listOf("com.bkash", "com.konasl.nagad", "com.dbbl", "com.islamibank", "com.primebank", "com.citybank", "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging", "com.android.messaging")

    fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun url(c: Context) = prefs(c).getString("url", "") ?: ""
    fun key(c: Context) = prefs(c).getString("key", "") ?: ""

    fun interesting(from: String, text: String): Boolean {
        val t = text.lowercase(Locale.ROOT); val f = from.lowercase(Locale.ROOT)
        val money = t.contains("tk") || t.contains("bdt") || t.contains("৳")
        val incoming = Regex("received|credited|deposit|cash in|cash-in|money in|you have received|পেয়েছেন").containsMatchIn(t)
        val known = SENDERS.any { f.contains(it) || t.contains(it) }
        return money && incoming && known
    }

    fun log(c: Context, line: String) {
        synchronized(lock) {
            val a = JSONArray(prefs(c).getString("log", "[]"))
            val n = JSONArray(); n.put(java.text.SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(java.util.Date()) + "  " + line)
            for (i in 0 until minOf(a.length(), 59)) n.put(a.get(i))
            prefs(c).edit().putString("log", n.toString()).apply()
        }
    }

    fun handle(c: Context, from: String, text: String) {
        if (!interesting(from, text)) return
        synchronized(lock) {
            val q = JSONArray(prefs(c).getString("queue", "[]"))
            // Avoid double-forwarding the same text (SMS + notification of the same message).
            val sig = (from.take(12) + "|" + text).hashCode().toString()
            val seen = prefs(c).getString("seen", "") ?: ""
            if (seen.split(",").contains(sig)) return
            prefs(c).edit().putString("seen", (listOf(sig) + seen.split(",").filter { it.isNotEmpty() }).take(40).joinToString(",")).apply()
            q.put(JSONObject().put("from", from).put("text", text).put("at", System.currentTimeMillis()))
            prefs(c).edit().putString("queue", q.toString()).apply()
        }
        log(c, "Caught message from " + from.ifEmpty { "?" })
        Thread { flush(c) }.start()
    }

    /** Sends everything waiting. Returns number still waiting. */
    fun flush(c: Context): Int {
        synchronized(lock) {
            val u = url(c); val k = key(c)
            val q = JSONArray(prefs(c).getString("queue", "[]"))
            if (q.length() == 0) return 0
            if (u.isEmpty() || k.isEmpty()) { log(c, "Set the server address and key first"); return q.length() }
            val left = JSONArray()
            for (i in 0 until q.length()) {
                val m = q.getJSONObject(i)
                val r = post(u, k, m)
                when {
                    r.first in 200..299 -> log(c, "Sent OK: " + r.second.take(90))
                    r.first == 401 -> { log(c, "Wrong key (401). Check the key in the admin panel."); left.put(m) }
                    r.first in 400..499 -> log(c, "Server refused (" + r.first + "), dropped")
                    else -> { log(c, "Could not send (" + r.first + "), will retry"); left.put(m) }
                }
            }
            prefs(c).edit().putString("queue", left.toString()).apply()
            if (left.length() > 0) schedule(c)
            return left.length()
        }
    }

    private fun post(u: String, k: String, m: JSONObject): Pair<Int, String> = try {
        val con = URL(u).openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.connectTimeout = 15000; con.readTimeout = 20000; con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json"); con.setRequestProperty("X-Api-Key", k)
        con.outputStream.use { it.write(JSONObject().put("from", m.optString("from")).put("text", m.optString("text")).put("date", m.optLong("at")).toString().toByteArray()) }
        val code = con.responseCode
        val body = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
        Pair(code, body)
    } catch (e: Exception) { Pair(-1, e.message ?: "network error") }

    fun testConnection(c: Context): String {
        val u = url(c); if (u.isEmpty()) return "Enter the server address first."
        return try {
            val con = URL(u + (if (u.contains("?")) "&" else "?") + "key=" + java.net.URLEncoder.encode(key(c), "UTF-8")).openConnection() as HttpURLConnection
            con.connectTimeout = 10000; con.readTimeout = 10000
            val code = con.responseCode; val body = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
            if (code in 200..299) "Server reachable ✓" else "Server answered $code: ${body.take(80)}"
        } catch (e: Exception) { "Cannot reach the server: " + (e.message ?: "") }
    }

    fun schedule(c: Context) {
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        js.schedule(JobInfo.Builder(77, ComponentName(c, RetryJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(false)
            .setBackoffCriteria(30000, JobInfo.BACKOFF_POLICY_EXPONENTIAL).setMinimumLatency(20000).build())
    }
    fun pending(c: Context) = JSONArray(prefs(c).getString("queue", "[]")).length()
}
