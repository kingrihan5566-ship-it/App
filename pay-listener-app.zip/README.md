# NakshiNoor Pay Listener (Android)

Reads money-received notifications/SMS from bKash, Nagad, Rocket (16216), Islami Bank, Prime Bank, City Bank
and sends them to your site (`/api/pay-app`). The site matches TrxID + amount and confirms the order automatically.

## Get the APK (no Android Studio needed)
1. Create a free GitHub repo, upload this whole folder (keep `.github/workflows/build.yml`).
2. Repo → **Actions → Build APK → Run workflow**. After ~4 min download the `NakshiNoorPayListener-apk` artifact → unzip → `app-release.apk`.
3. Copy to the phone, install (allow "unknown sources").
(Or open the folder in Android Studio → Build → Build APK.)

> Honest note: this source was written without an Android compiler available. If the build prints an error, send it to me and I will fix it.

## Set up on the phone (use a spare phone with the SIM that receives the money)
1. Open the app → paste **Server address** and **Secret key** from Admin → Own gateway → Phone app setup → *Save and test connection*.
2. Tap 1, 2, 3 (notification access, SMS, battery unrestricted). On Xiaomi/Oppo/Vivo/Samsung also turn on **Autostart** and lock the app in recent apps.
3. Tap *Send a test message*; the Activity log should say `Sent OK`. Check it appears in Admin → Received money.
4. Keep the phone charged and online.

## Free ready-made alternative
"SMS Gateway for Android" (sms-gate.app): set its webhook to `https://YOUR-SITE/api/pay-app?key=YOUR_KEY`, event `sms:received`. Works with the same server.

## Notes
- Messages are only forwarded if they look like money received (Tk + received/credited + a known sender).
- Failed sends are kept and retried automatically.
- Bank SMS often has no TrxID — those payments appear under *Payments to check* for you to approve.
