package com.nakshinoor.payapp

import android.content.ComponentName
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads notifications from every app (bKash, Nagad, Rocket, bank apps, SMS apps). Only money-received texts are forwarded. */
class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val c = applicationContext
            Forwarder.countNotif(c, sbn.packageName)
            val e = sbn.notification.extras
            val title = e.getCharSequence("android.title")?.toString() ?: ""
            val texts = LinkedHashSet<String>()
            e.getCharSequence("android.bigText")?.toString()?.let { texts.add(it) }
            e.getCharSequence("android.text")?.toString()?.let { texts.add(it) }
            e.getCharSequence("android.subText")?.toString()?.let { texts.add(it) }
            e.getCharSequence("android.summaryText")?.toString()?.let { texts.add(it) }
            e.getCharSequenceArray("android.textLines")?.forEach { texts.add(it.toString()) }
            val arr = e.getParcelableArray("android.messages")          // chat-style (Google Messages, Samsung Messages)
            if (arr != null) for (m in arr) if (m is Bundle) m.getCharSequence("text")?.toString()?.let { texts.add(it) }
            val from = if (title.isNotBlank()) title + " (" + sbn.packageName + ")" else sbn.packageName
            for (t in texts) if (t.isNotBlank()) Forwarder.handle(c, from, if (title.isNotBlank() && !t.contains(title)) "$title: $t" else t, "N")
        } catch (_: Exception) {}
    }
    override fun onListenerConnected() {
        Forwarder.prefs(applicationContext).edit().putBoolean("listenerUp", true).putLong("listenerAt", System.currentTimeMillis()).apply()
        Forwarder.log(applicationContext, "Notification reader connected"); Thread { Forwarder.flush(applicationContext) }.start()
    }
    override fun onListenerDisconnected() {
        Forwarder.prefs(applicationContext).edit().putBoolean("listenerUp", false).apply()
        Forwarder.log(applicationContext, "Notification reader disconnected — reconnecting")
        try { requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }
}
