package com.nakshinoor.payapp

import android.app.job.JobParameters
import android.app.job.JobService

class RetryJob : JobService() {
    override fun onStartJob(p: JobParameters): Boolean {
        Thread {
            try { SmsScan.auto(applicationContext) } catch (_: Exception) {}
            if (Forwarder.prefs(applicationContext).getBoolean("keep", true) && Forwarder.configured(applicationContext) && !KeepAliveService.alive(applicationContext)) KeepAliveService.start(applicationContext)
            val left = Forwarder.flush(applicationContext)
            jobFinished(p, left > 0)
        }.start()
        return true
    }
    override fun onStopJob(p: JobParameters) = true
}
