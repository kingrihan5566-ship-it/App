package com.nakshinoor.payapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val parts = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (parts.isEmpty()) return
        val from = parts[0].originatingAddress ?: ""
        val text = parts.joinToString("") { it.messageBody ?: "" }
        Forwarder.countSms(c.applicationContext)
        val pr = goAsync()
        Thread { try { Forwarder.handle(c.applicationContext, from, text, "S") } finally { pr.finish() } }.start()
    }
}
