package com.nakshinoor.payapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Keeps the app alive (so the phone does not kill it) and watches the SMS inbox for new messages. */
class KeepAliveService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var obs: ContentObserver? = null
    private val loop = object : Runnable {
        override fun run() { Thread { try { SmsScan.auto(applicationContext); Forwarder.flush(applicationContext) } catch (_: Exception) {} }.start(); h.postDelayed(this, 60_000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b = if (Build.VERSION.SDK_INT >= 26) { nm.createNotificationChannel(NotificationChannel("keep", "Payment listener", NotificationManager.IMPORTANCE_LOW)); Notification.Builder(this, "keep") } else Notification.Builder(this)
        val n = b.setContentTitle("Payment listener is running").setContentText("Watching for money-received messages").setSmallIcon(android.R.drawable.stat_notify_sync).setOngoing(true).build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(1, n)
        } catch (e: Exception) { Forwarder.log(this, "Keep-alive could not start: " + (e.message ?: "")); stopSelf(); return START_NOT_STICKY }
        if (obs == null) {
            obs = object : ContentObserver(h) {
                override fun onChange(selfChange: Boolean) { Thread { try { SmsScan.auto(applicationContext); Forwarder.flush(applicationContext) } catch (_: Exception) {} }.start() }
            }
            try { contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs!!) } catch (_: Exception) {}
        }
        h.removeCallbacks(loop); h.post(loop)
        return START_STICKY
    }

    override fun onDestroy() { h.removeCallbacks(loop); obs?.let { try { contentResolver.unregisterContentObserver(it) } catch (_: Exception) {} }; super.onDestroy() }

    companion object {
        fun start(c: Context) {
            try { val i = Intent(c, KeepAliveService::class.java); if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (_: Exception) {}
        }
        fun stop(c: Context) { try { c.stopService(Intent(c, KeepAliveService::class.java)) } catch (_: Exception) {} }
    }
}
