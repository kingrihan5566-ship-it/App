package com.nakshinoor.payapp

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.widget.*
import org.json.JSONArray

/** One screen, built in code (no extra libraries). */
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var site: EditText
    private lateinit var email: EditText
    private lateinit var pass: EditText
    private lateinit var url: EditText
    private lateinit var key: EditText
    private lateinit var paste: EditText
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 3000) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } }
    private fun bg(f: () -> Unit) = Thread { f() }.start()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(dp(18), dp(26), dp(18), dp(30)) }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#fff7fa")); addView(root) }
        fun label(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply { text = t; textSize = size; setTextColor(Color.parseColor("#2a1a22")); if (bold) setTypeface(typeface, Typeface.BOLD); setPadding(0, dp(12), 0, dp(4)) }
        fun field(hint: String, v: String, pw: Boolean = false) = EditText(this).apply { this.hint = hint; setText(v); setSingleLine(); inputType = if (pw) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI }
        val p = Forwarder.prefs(this)

        root.addView(label("NakshiNoor Pay Listener", 22f, true))
        status = label("", 13f); root.addView(status)

        root.addView(label("1. Sign in (gets the address and key for you)", 15f, true))
        site = field("Your site, e.g. nakshinoor.com", p.getString("site", "https://nakshinoor.com") ?: ""); root.addView(site)
        email = field("Admin email", p.getString("email", "") ?: ""); email.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS; root.addView(email)
        pass = field("Admin password", "", true); root.addView(pass)
        root.addView(btn("Sign in and connect") {
            val e = email.text.toString(); p.edit().putString("email", e.trim()).apply()
            toast("Signing in…")
            bg { val r = Forwarder.login(this, site.text.toString(), e, pass.text.toString())
                h.post { if (r == "OK") { pass.setText(""); url.setText(Forwarder.url(this)); key.setText(Forwarder.key(this)); toast("Connected ✓"); KeepAliveService.start(this); Forwarder.schedulePeriodic(this) } else toast(r) } }
        })
        root.addView(label("Or enter them yourself (Admin → Own gateway → Phone app setup)", 12f))
        url = field("Server address https://…/api/pay-app", Forwarder.url(this)); root.addView(url)
        key = field("Secret key", Forwarder.key(this)); root.addView(key)
        root.addView(btn("Save and test connection") {
            p.edit().putString("url", url.text.toString().trim()).putString("key", key.text.toString().trim()).apply()
            toast("Testing…"); bg { val r = Forwarder.testConnection(this); h.post { toast(r) }; Forwarder.flush(this) }
            KeepAliveService.start(this); Forwarder.schedulePeriodic(this)
        })

        root.addView(label("2. Permissions", 15f, true))
        root.addView(btn("Allow notification access") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) })
        root.addView(btn("Allow SMS (receive and read)") { if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.POST_NOTIFICATIONS), 1) })
        root.addView(btn("Never sleep (battery)") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } })
        root.addView(btn("Open app settings (Autostart / lock app)") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) })
        val keep = Switch(this).apply { text = "Keep running in background (recommended)"; isChecked = p.getBoolean("keep", true); setOnCheckedChangeListener { _, on -> p.edit().putBoolean("keep", on).apply(); if (on) KeepAliveService.start(this@MainActivity) else KeepAliveService.stop(this@MainActivity) } }
        root.addView(keep)
        val broad = Switch(this).apply { text = "Read every message with an amount (server picks the real ones)"; isChecked = p.getBoolean("broad", true); setOnCheckedChangeListener { _, on -> p.edit().putBoolean("broad", on).apply() } }
        root.addView(broad)

        root.addView(label("3. Import missed payments from the SMS inbox", 15f, true))
        val row = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL }
        for ((t, d) in listOf("Today" to 1, "3 days" to 3, "7 days" to 7, "30 days" to 30)) {
            row.addView(btn(t) { importInbox(d) }, android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row)
        root.addView(label("Or paste one message", 12f))
        paste = EditText(this).apply { hint = "Paste the SMS text here"; minLines = 2; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        root.addView(paste)
        root.addView(btn("Send this message") {
            val t = paste.text.toString().trim(); if (t.isEmpty()) { toast("Paste the message first."); return@btn }
            val ok = Forwarder.enqueue(this, "manual", t, System.currentTimeMillis(), force = true)
            toast(if (ok) "Sending…" else "This does not look like a received-money message."); if (ok) bg { Forwarder.flush(this) }; paste.setText("")
        })
        root.addView(btn("Send a test message") {
            Forwarder.enqueue(this, "bKash", "You have received Tk 1.00 from 01700000000. Fee Tk 0.00. Balance Tk 1.00. TrxID TEST" + (System.currentTimeMillis() % 100000) + " at 01/01/2026 10:00", System.currentTimeMillis(), force = true)
            bg { Forwarder.flush(this) }
        })
        root.addView(btn("Resend everything waiting") { toast("Sending…"); bg { val n = Forwarder.flush(this); h.post { toast(if (n == 0) "All sent ✓" else "$n still waiting") } } })

        root.addView(label("Activity", 15f, true))
        logView = TextView(this).apply { textSize = 11f; setTextColor(Color.parseColor("#4a3a42")); typeface = Typeface.MONOSPACE }
        root.addView(logView)
        setContentView(sv)
    }

    private fun importInbox(days: Int) {
        if (!SmsScan.canRead(this)) { toast("Allow SMS first (permission button above)."); if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS), 1); return }
        if (!Forwarder.configured(this)) { toast("Sign in first."); return }
        toast("Reading your inbox…")
        bg {
            val r = SmsScan.scan(this, System.currentTimeMillis() - days * 86_400_000L, force = true)
            Forwarder.log(this, "Import $days day(s): checked ${r.first} message(s), ${r.second} look like payments")
            val left = Forwarder.flush(this)
            h.post { toast("Checked ${r.first}, found ${r.second} payment message(s)" + (if (left > 0) ", $left waiting to send" else ", all sent ✓")) }
        }
    }

    private fun refresh() {
        val listener = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        val sms = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        val read = SmsScan.canRead(this)
        val bat = Build.VERSION.SDK_INT < 23 || (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        fun m(b: Boolean) = if (b) "✓" else "✗"
        status.text = "${m(Forwarder.configured(this))} Connected   ${m(listener)} Notifications   ${m(sms)} SMS   ${m(read)} Read inbox   ${m(bat)} Battery\nWaiting to send: ${Forwarder.pending(this)}"
        val a = JSONArray(Forwarder.prefs(this).getString("log", "[]")); val sb = StringBuilder()
        for (i in 0 until a.length()) sb.append(a.getString(i)).append("\n")
        logView.text = if (sb.isEmpty()) "Nothing yet." else sb.toString()
        if (listener) try { NotificationListenerService.requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }
    override fun onResume() {
        super.onResume(); h.post(tick)
        Forwarder.schedulePeriodic(this)
        if (Forwarder.configured(this) && Forwarder.prefs(this).getBoolean("keep", true)) KeepAliveService.start(this)
        bg { try { SmsScan.auto(this) } catch (_: Exception) {}; Forwarder.flush(this) }
    }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
