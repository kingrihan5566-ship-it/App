package com.nakshinoor.payapp

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build

/** Reads the SMS inbox. Used for manual import and as a safety net when live notifications are missed. */
object SmsScan {
    fun canRead(c: Context) = Build.VERSION.SDK_INT < 23 || c.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    /** Returns (messages checked, messages queued) or (-1, 0) when SMS permission is missing. */
    fun scan(c: Context, sinceMs: Long, force: Boolean = false, max: Int = 400): Pair<Int, Int> {
        if (!canRead(c)) return Pair(-1, 0)
        var checked = 0; var queued = 0
        try {
            c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), "date > ?", arrayOf(sinceMs.toString()), "date ASC")?.use { cur ->
                while (cur.moveToNext() && checked < max) {
                    checked++
                    val a = cur.getString(0) ?: ""; val b = cur.getString(1) ?: ""; val d = cur.getLong(2)
                    if (Forwarder.enqueue(c, a, b, d, force, quiet = true)) queued++
                }
            }
        } catch (e: Exception) { Forwarder.log(c, "SMS scan failed: " + (e.message ?: "")) }
        return Pair(checked, queued)
    }

    /** Background safety scan since the last one. */
    fun auto(c: Context) {
        val p = Forwarder.prefs(c); val now = System.currentTimeMillis()
        val since = p.getLong("lastScan", now - 30 * 60 * 1000L) - 2 * 60 * 1000L
        val r = scan(c, since)
        if (r.first >= 0) p.edit().putLong("lastScan", now).apply()
        if (r.second > 0) Forwarder.log(c, "Inbox scan found ${r.second} new payment message(s)")
    }
}
