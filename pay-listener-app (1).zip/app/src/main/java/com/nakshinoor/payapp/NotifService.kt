package com.nakshinoor.payapp

import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Reads notifications from every app (bKash, Nagad, Rocket, bank apps, SMS apps). Only money-received texts are forwarded. */
class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val e = sbn.notification.extras
            val title = e.getCharSequence("android.title")?.toString() ?: ""
            val texts = LinkedHashSet<String>()
            e.getCharSequence("android.bigText")?.toString()?.let { texts.add(it) }
            e.getCharSequence("android.text")?.toString()?.let { texts.add(it) }
            e.getCharSequence("android.summaryText")?.toString()?.let { texts.add(it) }
            e.getCharSequenceArray("android.textLines")?.forEach { texts.add(it.toString()) }
            // Chat-style notifications (Google Messages, Samsung Messages)
            val arr = e.getParcelableArray("android.messages")
            if (arr != null) for (m in arr) if (m is Bundle) m.getCharSequence("text")?.toString()?.let { texts.add(it) }
            val from = if (title.isNotBlank()) title + " (" + sbn.packageName + ")" else sbn.packageName
            for (t in texts) if (t.isNotBlank()) Forwarder.handle(applicationContext, from, if (title.isNotBlank() && !t.contains(title)) "$title: $t" else t)
        } catch (_: Exception) {}
    }
    override fun onListenerConnected() { Forwarder.log(applicationContext, "Notification reader connected"); Thread { Forwarder.flush(applicationContext) }.start() }
    override fun onListenerDisconnected() { Forwarder.log(applicationContext, "Notification reader disconnected — reconnecting"); try { requestRebind(android.content.ComponentName(this, NotifService::class.java)) } catch (_: Exception) {} }
}
