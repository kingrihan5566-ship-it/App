# NakshiNoor Pay Listener (Android)

Reads money-received notifications/SMS from bKash, Nagad, Rocket (16216), Islami Bank, Prime Bank, City Bank
and sends them to your site (`/api/pay-app`). The site matches TrxID + amount and confirms the order automatically.

## Get the APK (no Android Studio needed)
1. Create a free GitHub repo, upload this whole folder (keep `.github/workflows/build.yml`).
2. Repo → **Actions → Build APK → Run workflow**. After ~4 min download the `NakshiNoorPayListener-apk` artifact → unzip → `app-release.apk`.
3. Copy to the phone, install (allow "unknown sources").
(Or open the folder in Android Studio → Build → Build APK.)

> Honest note: this source was written without an Android compiler available. If the build prints an error, send it to me and I will fix it.

## Set up on the phone (use a spare phone with the SIM that receives the money)
1. Open the app → **Sign in** with your admin email and password (site: `nakshinoor.com`). The app fetches the address and key by itself. (Or paste them from Admin → Own gateway → Phone app setup.) The password is never stored.
2. Press: *Allow notification access*, *Allow SMS (receive and read)*, *Never sleep*. On Xiaomi/Oppo/Vivo/Samsung also turn on **Autostart** and lock the app in recent apps.
3. Press *Send a test message*; Activity should say `Sent OK`, and it appears in Admin → Received money. Admin → Phone app setup shows "last seen".
4. If a payment was missed (notification not read), press **Import: Today / 3 days / 7 days** — it reads your SMS inbox and sends the payment messages. You can also paste one message by hand.

## How it catches payments (3 ways, so nothing is missed)
- Live notifications from any app (bKash, Nagad, Rocket, banks, SMS apps).
- Live incoming SMS.
- A background watcher on the SMS inbox + a check every minute (and every 15 min even if the phone killed the app). Needs "Allow SMS" and "Keep running".
The server ignores duplicates, so sending the same message twice is safe.

## Free ready-made alternative
"SMS Gateway for Android" (sms-gate.app): set its webhook to `https://YOUR-SITE/api/pay-app?key=YOUR_KEY`, event `sms:received`. Works with the same server.

## Notes
- Messages are only forwarded if they look like money received (Tk + received/credited + a known sender).
- Failed sends are kept and retried automatically.
- Bank SMS often has no TrxID — those payments appear under *Payments to check* for you to approve.
